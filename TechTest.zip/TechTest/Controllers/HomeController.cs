﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TechTest.Models;

namespace TechTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly List<ChecklistListModel> _checklistList= new List<ChecklistListModel>
        {
            new ChecklistListModel { Id = 1, Name = "Hewan" },
            new ChecklistListModel { Id = 2, Name = "Negara"},
            new ChecklistListModel { Id = 3, Name = "Kendaraan"}
        };

        public IActionResult Index()
        {
            return View(_checklistList);
        }
    }
}
