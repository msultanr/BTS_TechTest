﻿using Microsoft.EntityFrameworkCore;
using TechTest.Models;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; }
    public DbSet<ChecklistItemModel> ChecklistItems { get; set; }
    public DbSet<ChecklistListModel> ChecklistLists { get; set; }
}