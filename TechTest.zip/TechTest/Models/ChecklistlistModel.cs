﻿namespace TechTest.Models
{
    public class ChecklistListModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
