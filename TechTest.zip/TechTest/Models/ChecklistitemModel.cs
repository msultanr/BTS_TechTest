﻿namespace TechTest.Models
{
    public class ChecklistItemModel
    {
        public int Id { get; set; }
        public int ChecklistId { get; set; }
        public string? Name { get; set; }
    }
}
